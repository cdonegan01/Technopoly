package cormacCoolClassesTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PlayerPortfolioTest {
	
	/**
	 * tEST
	 * @throws Exception
	 */

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
