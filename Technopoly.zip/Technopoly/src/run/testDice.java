package run;

public class testDice {

	public static void main(String[] args) {

		Dice.rollDice(); 
	}

}
