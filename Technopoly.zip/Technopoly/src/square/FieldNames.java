/**
 * 
 */
package square;

/**
 * @author Brendan
 *
 */
public enum FieldNames {
	ANTIQUES, CLASSIC, RETRO, ELITE;
}
