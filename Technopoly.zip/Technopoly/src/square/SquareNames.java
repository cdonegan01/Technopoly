/**
 * 
 */
package square;

/**
 * @author Brendan
 *
 */
public enum SquareNames {
	GO, IBM5100, ZX_SPECTRUM, MACINTOSH, ATARI_ST, NEXTSTATION, FREE_SESSION, IMAC, AREA_51, EEE_PC, THINK_PAD, MACBOOK_PRO;
	

	
	
}
