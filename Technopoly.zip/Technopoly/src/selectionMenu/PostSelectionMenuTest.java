 package selectionMenu;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PostSelectionMenuTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testConfirm() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintMenu() {
		fail("Not yet implemented");
	}

	@Test
	public void testChooseOption() {
		fail("Not yet implemented");
	}

}
